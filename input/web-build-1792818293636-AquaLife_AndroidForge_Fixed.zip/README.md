# AquaLife Android app

This ZIP is arranged for AndroidForge: `settings.gradle` and `build.gradle` are at the ZIP root.

## Project
- Android application using Kotlin and a WebView
- App interface is in `app/src/main/assets/index.html`
- App icon asset is in `app/src/main/assets/icon.svg`

## Build
Use AndroidForge with source ZIP input and build variant `debug` (or `auto`).
