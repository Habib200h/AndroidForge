# AquaLife — Water Tracker

A lightweight, responsive hydration tracker with a water-inspired blue theme, a custom pure-water wave icon, quick-add buttons, custom amounts, a configurable daily goal, local history, export/reset controls, and reminder settings.

## Run it

Because this is a Progressive Web App (PWA), serve this folder over HTTPS or localhost, then open `index.html` in a modern browser. For installability and offline caching, host it on an HTTPS static host and choose **Add to Home screen / Install app** in the browser.

A simple local test server (Python installed):

```sh
python -m http.server 8080
```

Then visit `http://localhost:8080` on the same device or computer. Browser notification permission generally requires HTTPS or localhost.

## Reminder limitation

The app can show browser notifications while its JavaScript is running. Mobile browsers and Android battery management may suspend timers when the app is closed, so this PWA cannot guarantee exact scheduled alerts while closed. For reliable background reminders, package a native Android implementation using Android `AlarmManager`/`WorkManager` and notification permission handling.

## Android APK

This deliverable is a working PWA source bundle, **not a compiled APK**. The current build environment has Java but no Android SDK or Gradle installation, so a native APK could not be compiled here. The HTML app can be wrapped in a native Android WebView project or packaged with Capacitor in an Android build environment.
